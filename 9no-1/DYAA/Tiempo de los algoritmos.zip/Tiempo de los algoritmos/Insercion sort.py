#Luis Alberto Vargas Glez. 
#19012140
#Diseño y análisis de algoritmos. 
import time
import random

inicio = time.time()

#codigo a medir. 
time.sleep(1)
def insercion(A):
    for i in range(len(A)):
        for j in range(i,0,-1):
            if(A[j-1] > A[j]):
                aux=A[j]
                A[j]=A[j-1]
                A[j-1]=aux
    print (A)
    return A
 
A=[random.randint(1,10000) for x in range(10000)]

#-----
fin = time.time()
#print (A)
#insercion(A)
print(fin - inicio)