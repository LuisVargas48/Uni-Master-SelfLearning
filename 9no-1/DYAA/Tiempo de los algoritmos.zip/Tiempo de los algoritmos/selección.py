#Luis Alberto Vargas Glez. 
#19012140. 
#Selección. 
import random
import time
inicio = time.time()

# codigo a medir
time.sleep(1)
def seleccion(arreglo):
    contador = 0
    longitud = len(arreglo)
    for i in range(longitud-1):
        for j in range(i+1, longitud):
            if arreglo[i] > arreglo[j]:
                arreglo[i], arreglo[j] = arreglo[j], arreglo[i]
                contador += 1
    print("Contador", contador )                        
    return arreglo

numeros = [random.randint(1,10000) for x in range(10000)]           

#-------
fin=time.time()
print(fin - inicio)   
#print(seleccion(numeros))  
     