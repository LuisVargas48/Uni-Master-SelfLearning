import 'cypress-mochawesome-reporter/register';
