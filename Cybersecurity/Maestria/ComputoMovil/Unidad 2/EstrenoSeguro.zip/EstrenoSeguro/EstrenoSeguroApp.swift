//
//  EstrenoSeguroApp.swift
//  EstrenoSeguro
//
//  Created by Luis A. Vargas Glez on 14/03/25.
//
import SwiftUI

@main
struct EstrenoSeguroApp: App {
    var body: some Scene {
        WindowGroup {
            AutoListView()
        }
    }
}
