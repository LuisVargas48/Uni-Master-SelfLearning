//
//  Auto.swift
//  EstrenoSeguro
//
//  Created by Luis A. vargas Glez on 14/03/25.
//

import Foundation

struct Auto: Identifiable, Decodable {
    let id: Int
    let marca: String
    let nombre: String
    let anio: Int
    let precio: String
    let imagen: String
    let kilometraje: String
    let motor: String
    let garantia: String
}

