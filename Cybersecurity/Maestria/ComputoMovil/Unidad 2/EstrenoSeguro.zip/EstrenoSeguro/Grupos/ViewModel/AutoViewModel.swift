//
//  AutoViewModel.swift
//  EstrenoSeguro
//
//  Created by Luis A. Vargas Glez on 14/03/25.
//

import Foundation

class AutoViewModel: ObservableObject {
    @Published var autos: [Auto] = []

    init() {
        loadAutos()
    }

    func loadAutos() {
        if let url = Bundle.main.url(forResource: "autos", withExtension: "json") {
            do {
                let data = try Data(contentsOf: url)
                let autos = try JSONDecoder().decode([Auto].self, from: data)
                self.autos = autos
            } catch {
                print("Error al cargar los autos: \(error)")
            }
        }
    }
}
