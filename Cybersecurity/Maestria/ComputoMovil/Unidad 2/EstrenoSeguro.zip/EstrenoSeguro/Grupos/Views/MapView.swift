//  MapView.swift
//  EstrenoSeguro
//
//  Created by Luis A. Vargas Glez on 14/03/25.
//

import Foundation
import CoreLocation

struct Sucursal: Identifiable {
    let id = UUID()  // Para cumplir con el protocolo Identifiable
    let coordenadas: CLLocationCoordinate2D
}





import SwiftUI
import MapKit

struct MapView: View {
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 20.6597, longitude: -103.3496), // Guadalajara
        span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
    )

    let sucursales = [
        Sucursal(coordenadas: CLLocationCoordinate2D(latitude: 20.6745, longitude: -103.3875)), // Punto 1
        Sucursal(coordenadas: CLLocationCoordinate2D(latitude: 20.6665, longitude: -103.3507)), // Punto 2
        Sucursal(coordenadas: CLLocationCoordinate2D(latitude: 20.6801, longitude: -103.3320)), // Punto 3
        Sucursal(coordenadas: CLLocationCoordinate2D(latitude: 20.6592, longitude: -103.3731)), // Punto 4
        Sucursal(coordenadas: CLLocationCoordinate2D(latitude: 20.6565, longitude: -103.3067))  // Punto 5
    ]

    var body: some View {
        Map(coordinateRegion: $region, annotationItems: sucursales) { location in
            MapPin(coordinate: location.coordenadas, tint: .blue)
        }
        .navigationTitle("Sucursales")
        .toolbar {
            Button("Regresar") {
                // Navegación de regreso
            }
        }
    }
}
