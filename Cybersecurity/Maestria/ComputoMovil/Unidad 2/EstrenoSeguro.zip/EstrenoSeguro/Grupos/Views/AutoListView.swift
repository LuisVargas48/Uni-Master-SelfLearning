//
//  AutoListView.swift
//  EstrenoSeguro
//
//  Created by Luis A. Vargas Glez on 14/03/25.
//

import SwiftUI

struct AutoListView: View {
    @StateObject var viewModel = AutoViewModel()

    var body: some View {
        NavigationView {
            List(viewModel.autos) { auto in
                NavigationLink(destination: AutoDetailView(auto: auto)) {
                    VStack(alignment: .leading) {
                        Text("\(auto.marca) \(auto.nombre)")
                            .font(.headline)
                        Text("Año: \(auto.anio) - Precio: \(auto.precio)")
                            .font(.subheadline)
                    }
                }
            }
            .navigationTitle("ESTRENO SEGURO")
            .foregroundColor(.white)
            .background(Color.white)
        }
    }
}
