//
//  AutoDetailView.swift
//  EstrenoSeguro
//
//  Created by Luis A. Vargas Glez on 14/03/25.
//

import SwiftUI

struct AutoDetailView: View {
    let auto: Auto

    var body: some View {
        VStack {
            Image(auto.imagen)
                .resizable()
                .scaledToFit()
                .frame(height: 200)
                .padding()

            Text("\(auto.marca) \(auto.nombre)")
                .font(.title)
                .fontWeight(.bold)
                .padding()

            Text("Año: \(auto.anio)")
            Text("Precio: \(auto.precio)")
            Text("Kilometraje: \(auto.kilometraje)")
            Text("Motor: \(auto.motor)")
            Text("Garantía: \(auto.garantia)")

            Spacer()

            Button("Regresar") {
                // Navegación de regreso
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .navigationTitle("Detalles del Auto")
    }
}
