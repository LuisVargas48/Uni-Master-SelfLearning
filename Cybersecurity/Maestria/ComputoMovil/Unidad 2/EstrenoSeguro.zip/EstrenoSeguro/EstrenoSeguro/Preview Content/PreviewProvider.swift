//
//  PreviewProvider.swift
//  EstrenoSeguro
//
//  Created by Luis A. Vargas Glez on 14/03/25.
//

import SwiftUI

struct PreviewProvider_Previews: PreviewProvider {
    static var previews: some View {
        Text("Vista previa funcionando correctamente")
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
    }
}


