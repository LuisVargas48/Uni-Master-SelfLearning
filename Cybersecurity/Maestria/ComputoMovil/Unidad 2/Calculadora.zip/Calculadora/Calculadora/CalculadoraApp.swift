//
//  CalculadoraApp.swift
//  Calculadora
//
//  Created by Luis Alberto Vargas Glez on 13/03/25.
//

import SwiftUI

@main
struct CalculadoraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
