//
//  ContentView.swift
//  Calculadora
//
//  Created by Luis Alberto Vargas Glez on 13/03/25.
//

import SwiftUI

struct ContentView: View {
    @State private var display = "0"
    @State private var currentValue: Double = 0
    @State private var currentOperation: String? = nil

    let buttons = [
        ["7", "8", "9", "/"],
        ["4", "5", "6", "x"],
        ["1", "2", "3", "-"],
        ["0", "AC", "=", "+"]
    ]

    var body: some View {
        VStack(spacing: 10) {
            Text(display)
                .font(.largeTitle)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)

            ForEach(buttons, id: \.self) { row in
                HStack(spacing: 10) {
                    ForEach(row, id: \.self) { button in
                        Button(action: {
                            self.buttonTapped(button)
                        }) {
                            Text(button)
                                .font(.title)
                                .frame(width: 70, height: 70)
                                .background(isOperator(button) ? Color.orange : Color.black)
                                .foregroundColor(.white)
                                .cornerRadius(35)
                        }
                    }
                }
            }
        }
        .padding()
    }

    // Función para identificar si el botón es una operación
    func isOperator(_ symbol: String) -> Bool {
        return ["+", "-", "x", "/"].contains(symbol)
    }

    func buttonTapped(_ button: String) {
        switch button {
        case "0"..."9":
            if display == "0" {
                display = button
            } else {
                display += button
            }
        case "+", "-", "x", "/":
            currentValue = Double(display) ?? 0
            currentOperation = button
            display = "0"
        case "=":
            let newValue = Double(display) ?? 0
            if let operation = currentOperation {
                switch operation {
                case "+": display = "\(currentValue + newValue)"
                case "-": display = "\(currentValue - newValue)"
                case "x": display = "\(currentValue * newValue)"
                case "/": display = newValue != 0 ? "\(currentValue / newValue)" : "Error"
                default: break
                }
            }
        case "AC":
            display = "0"
            currentValue = 0
            currentOperation = nil
        default:
            break
        }
    }
}
