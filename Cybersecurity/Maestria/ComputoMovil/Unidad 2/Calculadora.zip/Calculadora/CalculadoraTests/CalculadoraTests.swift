//
//  CalculadoraTests.swift
//  CalculadoraTests
//
//  Created by Gisela Gonzalez Gonzalez on 13/03/25.
//

import Testing

struct CalculadoraTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
